# Riksdagens Protokoll (Parliamentary Debates) in your browser (powered by JupyterLite)

Welfare State Analytics notebooks deployed as a static site to GitHub Pages.

## ✨ Try it in your browser ✨

➡️ **https://roger-mahler.github.io/riksprot-jupyterlite**

![github-pages](https://user-images.githubusercontent.com/591645/120649478-18258400-c47d-11eb-80e5-185e52ff2702.gif)

## Requirements

JupyterLite is being tested against modern web browsers:

- Firefox 90+
- Chromium 89+

## Usage
