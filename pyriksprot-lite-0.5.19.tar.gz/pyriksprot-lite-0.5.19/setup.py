# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['utility',
 'westac',
 'westac.riksprot',
 'westac.riksprot.kb_labb',
 'westac.riksprot.parlaclarin']

package_data = \
{'': ['*']}

install_requires = \
['jupyterlite>=0.1.0-alpha.21,<0.2.0']

setup_kwargs = {
    'name': 'pyriksprot-lite',
    'version': '0.5.19',
    'description': 'Welfare State Analytics - Riksdagens Protokoll',
    'long_description': '# Riksdagens Protokoll (Parliamentary Debates) in your browser (powered by JupyterLite)\n\nWelfare State Analytics notebooks deployed as a static site to GitHub Pages.\n\n## ✨ Try it in your browser ✨\n\n➡️ **https://roger-mahler.github.io/riksprot-jupyterlite**\n\n![github-pages](https://user-images.githubusercontent.com/591645/120649478-18258400-c47d-11eb-80e5-185e52ff2702.gif)\n\n## Requirements\n\nJupyterLite is being tested against modern web browsers:\n\n- Firefox 90+\n- Chromium 89+\n\n## Usage\n',
    'author': 'Roger Mähler',
    'author_email': 'roger.mahler@hotmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://westac.se',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8.0,<3.9.0',
}


setup(**setup_kwargs)
