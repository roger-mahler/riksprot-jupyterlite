from .speech_text import SpeechTextRepository
from .codecs import (
    Codecs,
    PersonCodecs,
    CODE_TABLENAMES
)
